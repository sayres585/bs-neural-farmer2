# BS Neural Farmer Companion (v0.1)

A cloud-deployable companion for Brawl Stars match journaling, trophy tracking,
strategy summaries, screenshot archiving, and an offline reinforcement-learning
practice arena.

## Scope and limitations

This is **not** an autonomous Brawl Stars player. It does not read game memory,
identify live opponents, inject touches, automate matches, or farm trophies.
iOS Safari cannot control another app or keep a web page running as a background
game-playing agent. The Q-learning component trains only in the included toy
arena. Match analytics are based on results entered by the user.

## Run locally

Requires Python 3.11+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open http://127.0.0.1:8000

## Deploy without a Mac

1. Create a GitHub repository and upload this project.
2. Create a free Render account and connect the repository as a Web Service.
3. Render can use the included `render.yaml` / `Dockerfile`.
4. Open the deployed HTTPS URL in Safari, then Share -> Add to Home Screen.

Free hosting availability, sleep behavior, and persistent-disk allowances can
change. The included data directory may reset on ephemeral free instances.
Do not treat free hosting as durable storage; export/backup data before relying
on it.

## API

- `GET /api/health` service health
- `GET /api/stats` match and trophy summary
- `POST /api/matches` record a match
- `POST /api/train?episodes=250` train the offline Q-learning practice agent
- `GET /api/policy` inspect the learned Q table
- `GET /api/strategy` summarize recorded match history
- `POST /api/review-image` archive a PNG/JPEG/WebP screenshot (max 8 MB)

## Validation

Run:
```bash
python -m compileall app
python - <<'PY'
from app.rl_agent import QLearningAgent
agent = QLearningAgent('/tmp/bs-qtable-test.json')
result = agent.train(episodes=25)
assert result['episodes'] == 25
print(result)
PY
```
