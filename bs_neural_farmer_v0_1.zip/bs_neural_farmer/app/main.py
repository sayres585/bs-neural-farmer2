from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import json
import os
import uuid

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from .rl_agent import QLearningAgent

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
UPLOADS = DATA / "review_uploads"
DATA.mkdir(exist_ok=True)
UPLOADS.mkdir(exist_ok=True)
MATCHES_FILE = DATA / "matches.json"

app = FastAPI(title="BS Neural Farmer Companion", version="0.1.0")
agent = QLearningAgent(str(DATA / "qtable.json"))

def read_matches():
    if not MATCHES_FILE.exists():
        return []
    try:
        return json.loads(MATCHES_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []

def write_matches(items):
    MATCHES_FILE.write_text(json.dumps(items, indent=2), encoding="utf-8")

class MatchEntry(BaseModel):
    brawler: str = Field(min_length=1, max_length=50)
    mode: str = Field(min_length=1, max_length=50)
    result: str
    trophies_delta: int = Field(ge=-100, le=100)
    notes: str = Field(default="", max_length=500)

@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse((BASE / "web" / "index.html").read_text(encoding="utf-8"))

@app.get("/api/health")
def health():
    return {"ok": True, "service": "BS Neural Farmer Companion", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/stats")
def stats():
    matches = read_matches()
    wins = sum(1 for m in matches if m["result"] == "win")
    losses = sum(1 for m in matches if m["result"] == "loss")
    delta = sum(m["trophies_delta"] for m in matches)
    return {"matches": len(matches), "wins": wins, "losses": losses,
            "win_rate": round(wins / len(matches), 3) if matches else 0,
            "trophies_delta": delta, "recent": matches[-10:][::-1]}

@app.post("/api/matches")
def add_match(entry: MatchEntry):
    if entry.result not in ("win", "loss", "draw"):
        raise HTTPException(400, "result must be win, loss, or draw")
    items = read_matches()
    item = entry.model_dump()
    item.update({"id": str(uuid.uuid4()), "created_at": datetime.now(timezone.utc).isoformat()})
    items.append(item)
    write_matches(items)
    return {"saved": True, "match": item}

@app.post("/api/train")
def train(episodes: int = 250):
    if episodes < 1 or episodes > 10000:
        raise HTTPException(400, "episodes must be between 1 and 10000")
    return agent.train(episodes)

@app.get("/api/policy")
def policy():
    return {"states": agent.q, "actions": ["advance", "retreat", "strafe", "attack", "super", "heal"],
            "scope": "offline practice simulator only"}

@app.post("/api/review-image")
async def review_image(file: UploadFile = File(...)):
    # Store a user-provided screenshot for later manual review.
    # No game memory access, live control, or automated opponent tracking.
    allowed = {"image/png", "image/jpeg", "image/webp"}
    if file.content_type not in allowed:
        raise HTTPException(415, "Upload PNG, JPEG, or WebP only")
    data = await file.read()
    if len(data) > 8 * 1024 * 1024:
        raise HTTPException(413, "Image must be 8 MB or smaller")
    suffix = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp"}[file.content_type]
    name = f"{uuid.uuid4().hex}{suffix}"
    (UPLOADS / name).write_bytes(data)
    return {"stored": True, "filename": name,
            "message": "Screenshot saved for manual review; no automatic game control is performed."}

@app.get("/api/strategy")
def strategy():
    matches = read_matches()
    if not matches:
        return {"summary": "Add match results to begin building a personal performance history.",
                "suggestions": ["Record at least 10 matches", "Compare modes separately", "Review losses for recurring mistakes"]}
    by_mode = {}
    for m in matches:
        row = by_mode.setdefault(m["mode"], {"matches": 0, "wins": 0, "trophy_delta": 0})
        row["matches"] += 1
        row["wins"] += int(m["result"] == "win")
        row["trophy_delta"] += m["trophies_delta"]
    best = max(by_mode.items(), key=lambda kv: (kv[1]["wins"] / kv[1]["matches"], kv[1]["trophy_delta"]))
    return {"summary": f"Your strongest recorded mode is {best[0]}.",
            "by_mode": by_mode,
            "suggestions": ["Compare win rate and trophy change together",
                           "Avoid drawing conclusions from fewer than 10 matches",
                           "Review notes from losses before changing your strategy"]}

