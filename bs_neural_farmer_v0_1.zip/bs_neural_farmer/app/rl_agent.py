"""Small tabular Q-learning agent for a self-contained practice arena.

This deliberately trains in a toy environment, not inside Brawl Stars.
It is useful for validating the learning loop before connecting legitimate
match-review data to the analytics layer.
"""
from __future__ import annotations
import json
import random
from pathlib import Path
from typing import Dict, List, Tuple

ACTIONS = ("advance", "retreat", "strafe", "attack", "super", "heal")
STATE_BUCKETS = ("safe", "threatened", "low_health", "enemy_near", "objective")

class PracticeArena:
    """Tiny deterministic-ish arena used only for offline policy experiments."""
    def reset(self) -> str:
        self.health = 100
        self.enemy_health = 100
        self.distance = 3
        self.objective = 0
        self.steps = 0
        return self.state()

    def state(self) -> str:
        if self.health <= 30:
            return "low_health"
        if self.distance <= 1:
            return "enemy_near"
        if self.health < 60:
            return "threatened"
        if self.objective >= 3:
            return "objective"
        return "safe"

    def step(self, action: str) -> Tuple[str, float, bool]:
        self.steps += 1
        reward = -0.05
        if action == "advance":
            self.distance = max(0, self.distance - 1)
            reward += 0.1
        elif action == "retreat":
            self.distance = min(3, self.distance + 1)
            reward += 0.02 if self.health < 60 else -0.03
        elif action == "strafe":
            reward += 0.02
        elif action == "attack":
            if self.distance <= 2:
                self.enemy_health -= random.randint(8, 18)
                reward += 1.0
            else:
                reward -= 0.2
            self.health -= random.randint(2, 9)
        elif action == "super":
            if self.distance <= 1:
                self.enemy_health -= random.randint(18, 30)
                reward += 1.5
            else:
                reward -= 0.25
            self.health -= random.randint(2, 7)
        elif action == "heal":
            self.health = min(100, self.health + 16)
            reward += 0.25
        self.objective += 1 if action in ("advance", "strafe") else 0
        # The simulated opponent applies pressure each turn.
        if self.distance <= 2 and action not in ("retreat", "heal"):
            self.health -= random.randint(3, 8)
        done = self.health <= 0 or self.enemy_health <= 0 or self.steps >= 40
        if self.enemy_health <= 0:
            reward += 5.0
        if self.health <= 0:
            reward -= 4.0
        return self.state(), reward, done

class QLearningAgent:
    def __init__(self, path: str = "data/qtable.json", alpha=0.15, gamma=0.92,
                 epsilon=0.25):
        self.path = Path(path)
        self.alpha, self.gamma, self.epsilon = alpha, gamma, epsilon
        self.q: Dict[str, Dict[str, float]] = {}
        self.load()

    def _row(self, state: str) -> Dict[str, float]:
        if state not in self.q:
            self.q[state] = {a: 0.0 for a in ACTIONS}
        return self.q[state]

    def choose(self, state: str, explore: bool = True) -> str:
        row = self._row(state)
        if explore and random.random() < self.epsilon:
            return random.choice(ACTIONS)
        best = max(row.values())
        return random.choice([a for a, v in row.items() if v == best])

    def update(self, state: str, action: str, reward: float, next_state: str,
               done: bool) -> None:
        row = self._row(state)
        next_best = 0.0 if done else max(self._row(next_state).values())
        row[action] += self.alpha * (reward + self.gamma * next_best - row[action])

    def train(self, episodes: int = 250) -> dict:
        env = PracticeArena()
        wins = 0
        total_reward = 0.0
        for _ in range(episodes):
            state = env.reset()
            done = False
            episode_reward = 0.0
            while not done:
                action = self.choose(state, explore=True)
                next_state, reward, done = env.step(action)
                self.update(state, action, reward, next_state, done)
                state = next_state
                episode_reward += reward
            wins += int(env.enemy_health <= 0 and env.health > 0)
            total_reward += episode_reward
        self.epsilon = max(0.03, self.epsilon * 0.985)
        self.save()
        return {
            "episodes": episodes,
            "simulated_wins": wins,
            "win_rate": round(wins / episodes, 4),
            "average_reward": round(total_reward / episodes, 3),
            "epsilon": round(self.epsilon, 4),
            "warning": "These are practice-arena simulation results, not Brawl Stars results."
        }

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.q, indent=2), encoding="utf-8")

    def load(self) -> None:
        if self.path.exists():
            try:
                self.q = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                self.q = {}
